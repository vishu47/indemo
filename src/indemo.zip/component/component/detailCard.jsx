import React from 'react';
import Bed from '../assets/img/bed.png';
import Dbed from '../assets/img/bed-double.png';
import Expand from '../assets/img/expand.png';
import Bath from '../assets/img/bath.png';
import Check from '../assets/img/check.png';
import Bus from '../assets/img/bus.png';
import Gym from '../assets/img/gym.png';
import Hosp from '../assets/img/hospital-line.png';
import Lib from '../assets/img/library.png';
import Tree from '../assets/img/tree.png';

const DetailCard = () => {
    return (
        <>
            <section>

                <p className='text-[32px] text-std py-6' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>Details</p>
                <div className='grid md:grid-cols-4 sm:grid-cols-2 gap-4 md:grid-flow-col sm:grid-flow-row'>
                    <div className='border-[1px] p-4 px-6 border-[#341F87] rounded-lg' style={{ "boxShadow": "0px 4px 4px rgba(134, 104, 253, 0.2)" }}>
                        <ul className='flex flex-col'>
                            <li className='mb-2'>
                                <img src={Bed} alt="" />
                            </li>
                            <li className='text-std shadow-shadow-std text-xl font-semibold' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>BHK</li>
                            <li>3BHK</li>
                        </ul>
                    </div>
                    <div className='border-[1px] p-4 px-6 border-[#341F87] rounded-lg' style={{ "boxShadow": "0px 4px 4px rgba(134, 104, 253, 0.2)" }}>
                        <ul className='flex flex-col'>
                            <li className='mb-2'>
                                <img src={Bath} alt="" />
                            </li>
                            <li className='text-std shadow-shadow-std text-xl font-semibold' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>Bathroom</li>
                            <li>2</li>
                        </ul>
                    </div>
                    <div className='border-[1px] p-4 px-6 border-[#341F87] rounded-lg' style={{ "boxShadow": "0px 4px 4px rgba(134, 104, 253, 0.2)" }}>
                        <ul className='flex flex-col'>
                            <li className='mb-2'>
                                <img src={Dbed} alt="" />
                            </li>
                            <li className='text-std shadow-shadow-std text-xl font-semibold' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>Furnishing Status</li>
                            <li>Semi-Furnished</li>
                        </ul>
                    </div>
                    <div className='border-[1px] p-4 px-6 border-[#341F87] rounded-lg' style={{ "boxShadow": "0px 4px 4px rgba(134, 104, 253, 0.2)" }}>
                        <ul className='flex flex-col'>
                            <li className='mb-2'>
                                <img src={Expand} alt="" />
                            </li>
                            <li className='text-std shadow-shadow-std text-xl font-semibold' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>Super Build Area</li>
                            <li>1418 Sq.ft</li>
                        </ul>
                    </div>
                </div>
                <p className='text-[32px] text-std py-6' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>Features & Amenities</p>
                <div className="">
                    <ul className='flex justify-start flex-row gap-12'>
                        <li className='flex items-center'>
                            <img className='w-4 h-4' src={Check} alt="" />
                            <p style={{"fontWeight": "500"}} className='uppercase ml-3'>CCTV</p>
                        </li>
                        <li className='flex items-center'>
                            <img className='w-4 h-4' src={Check} alt="" />
                            <p style={{"fontWeight": "500"}} className=' ml-3'>Security</p>
                        </li>
                        <li className='flex items-center'>
                            <img className='w-4 h-4' src={Check} alt="" />
                            <p style={{"fontWeight": "500"}} className=' ml-3'>Life</p>
                        </li>
                    </ul>
                </div>
                <IconComponent />
            </section>
        </>
    );
}

export default DetailCard;



export const IconComponent = () => {
    return (
        <>
            <p className='text-[32px] text-std py-6' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>Nearby</p>
            <section className='grid md:grid-flow-col sm:grid-flow-row lg:grid-cols-10 md:grid-cols-5 sm:grid-cols-3 gap-4'>
                <div className='bg-[#352089] p-2 rounded-lg flex justify-center flex-col items-center' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                    <img src={Hosp} alt="" className='w-[2.5rem]' />
                    <p className='text-white py-2'>Hospital</p>
                </div>
                <div className='bg-[#352089] p-2 rounded-lg flex justify-center flex-col items-center' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                    <img src={Tree} alt="" className='w-[2.5rem]' />
                    <p className='text-white py-2'>Park</p>
                </div>
                <div className='bg-[#352089] p-2 rounded-lg flex justify-center flex-col items-center' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                    <img src={Bus} alt="" className='w-[2.5rem]' />
                    <p className='text-white py-2'>Bus</p>
                </div>
                <div className='bg-[#352089] p-2 rounded-lg flex justify-center flex-col items-center' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                    <img src={Lib} alt="" className='w-[2.5rem]' />
                    <p className='text-white py-2'>Hospital</p>
                </div>
                <div className='bg-[#352089] p-2 rounded-lg flex justify-center flex-col items-center' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>
                    <img src={Gym} alt="" className='w-[2.5rem]' />
                    <p className='text-white py-2'>Hospital</p>
                </div>
            </section>
        </>
    )
}