import React, { useState } from 'react';

const Header = () => {

    const [sidebar , setSidebar] = useState('-left-[120%]')

    const SidebarActionOpen = () => {
        setSidebar("-left-[0%]")
    }
    const SidebarActionClose = () => {
        setSidebar("-left-[120%]")
    }

    return (
        <>
            <section className='h-16 bg-white flex justify-between items-center lg:px-16 md:px-8 sm:px-4' style={{ "boxShadow": "0px 3px 6px #1e1d1d" }}>
                <ul>
                    <li className='tracking-wider text-2xl font-semibold' style={{ "textShadow": "0px 3.5px 3px #c5c5c5" }}>
                        Propertybhavan
                    </li>
                </ul>
                <div className='sm:hidden md:block'>
                    <ul className='flex flex-row justify-between '>
                        <li className='tracking-wider px-6 lg:text-2xl md:text-xl font-semibold'>
                            Home
                        </li>
                        <li className='tracking-wider px-6 lg:text-2xl md:text-xl font-semibold'>
                            List Your Property
                        </li>
                        <li className='tracking-wider px-6 lg:text-2xl md:text-xl font-semibold'>
                            Blog
                        </li>
                        <li className='tracking-wider px-4'>
                            <svg xmlns="http://www.w3.org/2000/svg" className="w-8 h-8 std-color text-[#7f56d9]" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
                            </svg>
                        </li>
                    </ul>
                </div>
                <div className='md:hidden sm:block'>
                    <ul className='flex flex-row justify-between '>
                        <li className='tracking-wider px-4'>
                            <svg xmlns="http://www.w3.org/2000/svg" onClick={SidebarActionOpen} fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-8 h-8 std-color text-[#7f56d9]">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                            </svg>
                        </li>
                    </ul>
                </div>
                {/* sidebad section start*/}
                <div className={`${sidebar} bg-white absolute w-full top-0  h-screen ease-in-out duration-1000`}>
                    <div className=''>
                        <div className='h-16 bg-white flex justify-between items-center px-4' style={{ "boxShadow": "0px 3px 6px #1e1d1d" }}>
                            <ul className='flex justify-between w-full items-center'>
                                <li className='tracking-wider text-2xl font-semibold' style={{ "textShadow": "0px 3.5px 3px #c5c5c5" }}>
                                    Propertybhavan
                                </li>
                                <li className='tracking-wider text-2xl font-semibold' style={{ "textShadow": "0px 3.5px 3px #c5c5c5" }}>
                                    <svg xmlns="http://www.w3.org/2000/svg" onClick={SidebarActionClose} fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-6 h-6 std-color text-[#7f56d9]">
                                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                                    </svg>

                                </li>
                            </ul>
                        </div>
                        <ul className='flex flex-col justify-between py-8'>
                            <li className='tracking-wider mx-2 px-2 py-2 my-2 rounded-md hover:bg-[#7f56d9] w-auto hover:text-white text-xl font-semibold border-[#7f56d9] border-[0.5px]'>
                                Home
                            </li>
                            <li className='tracking-wider mx-2 px-2 py-2 my-2 rounded-md hover:bg-[#7f56d9] w-auto hover:text-white text-xl font-semibold border-[#7f56d9] border-[0.5px]'>
                                List Your Property
                            </li>
                            <li className='tracking-wider mx-2 px-2 py-2 my-2 rounded-md hover:bg-[#7f56d9] w-auto hover:text-white text-xl font-semibold border-[#7f56d9] border-[0.5px]'>
                                Blog
                            </li>
                            <li className='tracking-wider mx-2 py-2 my-2'>
                                <svg xmlns="http://www.w3.org/2000/svg"  className="w-8 h-8 text-[#7f56d9]" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M17.982 18.725A7.488 7.488 0 0012 15.75a7.488 7.488 0 00-5.982 2.975m11.963 0a9 9 0 10-11.963 0m11.963 0A8.966 8.966 0 0112 21a8.966 8.966 0 01-5.982-2.275M15 9.75a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                            </li>
                        </ul>
                    </div>
                </div>
                {/* sidebad section end*/}
            </section>
        </>
    );
}

export default Header;
