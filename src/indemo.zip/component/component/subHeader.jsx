import React from 'react';

const SubHeader = () => {
    return (
        <>
            <section className='md:mt-0 sm:mt-4'>
                <div className="">
                    <ul className='flex md:justify-center sm:justify-start sm:pb-2 md:pb-0 flex-row lg:gap-20 md:gap-16 sm:gap-12 sm:overflow-scroll md:overflow-auto'>
                        <li className='cursor-pointer md:text-[22px] sm:text-[20px] text-std border-b-2 pb-2 px-4 border-[#7f56d9]'>Overview</li>
                        <li className="cursor-pointer md:text-[22px] sm:text-[20px]" >Details</li>
                        <li className="cursor-pointer md:text-[22px] sm:text-[20px] whitespace-pre" >Features &nbsp;& &nbsp;Aminities</li>
                        <li className="cursor-pointer md:text-[22px] sm:text-[20px]" >Nearby</li>
                    </ul>
                </div>
                <div>
                    <p className='text-[32px] text-std py-6' style={{"textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)"}}>Overview</p>
                    <p className='lg:w-2/3 md:w-full' style={{"fontSize":"20px" ,"lineHeight": "24px"}}>Property taxes are charged by local government entities, such as KMC, and are due by
                        the owner of the property. The amount of KMC property tax that must be paid may
                        vary. Thus, it depends on the location and a number of other criteria. KMC approved
                        the new Unit Area Assessment (UAA) mechanism for calculating property taxes in
                        March 2017.</p>
                </div>
            </section>
        </>
    );
}

export default SubHeader;
