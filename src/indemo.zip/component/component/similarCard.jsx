import React from 'react';
import Aprt from '../assets/img/aprt.png'
import LOcation from '../assets/img/location.png'
import Location1 from '../assets/img/location1.png'

const SimilarCard = () => {
    return (
        <>
            <section>
                <p className='text-[32px] text-std py-6' style={{ "textShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)" }}>Similar Properties</p>
                {/* <div className="flex gap-6">

                    <div className='p-4 w-[400px]   rounded-lg border-[0.25px] border-[#000]' style={{ "boxShadow": "0px 2px 4px rgba(0, 0, 0, 0.25)" }}>
                        <img className='w-full' src={Aprt} alt="" />
                        <div className="px-4">
                            <p className='text-2xl font-semibold py-4'>2BHK Apartment for Sale</p>
                            <div className='flex justify-between flex-row pb-8'>
                                <div className='flex items-center'>
                                    <img className='w-5 h-5' src={LOcation} alt="" />
                                    <p className='text-[16px] font-normal ml-2'>Behala</p>
                                </div>
                                <div className='text-[16px] font-normal'>
                                    ₹15,000
                                </div>
                            </div>
                            <div className="flex flex-col gap-2">
                                <button className='bg-[#7F56D9] py-2 rounded-md text-white text-xl' style={{ "boxShadow": "0px 2px 4px #000" }}> Contact Now </button>
                                <button className='border-[1px] border-[] py-2 rounded-md text-xl' style={{ "boxShadow": "rgb(171 164 164) 0px 2px 4px" }}> Learn More </button>
                            </div>
                        </div>
                    </div>

                    <div className='p-4 w-[400px]   bg-[#4B2FB7] rounded-lg border-[0.25px] border-[#000]' style={{ "boxShadow": "0px 2px 4px rgba(0, 0, 0, 0.25)" }}>
                        <img className='w-full' src={Aprt} alt="" />
                        <div className="px-4">
                            <p className='text-2xl font-semibold py-4 text-white'>2BHK Apartment for Sale</p>
                            <div className='flex justify-between flex-row pb-8'>
                                <div className='flex items-center'>
                                    <img className='w-5 h-5 text-white' src={Location1} alt="" />
                                    <p className='text-[16px] font-normal ml-2 text-white'>Behala</p>
                                </div>
                                <div className='text-[16px] font-normal text-white'>
                                    ₹15,000
                                </div>
                            </div>
                            <div className="flex flex-col gap-2">
                                <button className='bg-[#7F56D9] py-2 rounded-md text-white text-xl' style={{ "boxShadow": "0px 2px 4px #000" }}> Contact Now </button>
                                <button className='border-[1px] bg-white border-[] py-2 rounded-md text-xl' style={{ "boxShadow": "rgb(0,0,0,0.45) 0px 2px 4px" }}> Learn More </button>
                            </div>
                        </div>
                    </div>

                    <div className='p-4 w-[400px]  bg-[#9277FB] rounded-lg border-[0.25px] border-[#000]' style={{ "boxShadow": "0px 2px 4px rgba(0, 0, 0, 0.25)" }}>
                        <img className='w-full' src={Aprt} alt="" />
                        <div className="px-4">
                            <p className='text-2xl font-semibold py-4 text-white'>2BHK Apartment for Sale</p>
                            <div className='flex justify-between flex-row pb-8'>
                                <div className='flex items-center'>
                                    <img className='w-5 h-5 text-white' src={Location1} alt="" />
                                    <p className='text-[16px] font-normal ml-2 text-white'>Behala</p>
                                </div>
                                <div className='text-[16px] font-normal text-white'>
                                    ₹15,000
                                </div>
                            </div>
                            <div className="flex flex-col gap-2">
                                <button className='bg-[#7F56D9] py-2 rounded-md text-white text-xl' style={{ "boxShadow": "0px 2px 4px #000" }}> Contact Now </button>
                                <button className='border-[1px] bg-white border-[] py-2 rounded-md text-xl' style={{ "boxShadow": "0px 2px 4px #000" }}> Learn More </button>
                            </div>
                        </div>
                    </div>
                </div> */}

                {/* <div className="grid lg:grid-flow-col md:grid-flow-row sm:grid-flow-row lg:grid-cols-3 md:grid-cols-2 sm:grid-cols-1 gap-6"> */}
                <div className="grid grid-flow-col lg:grid-cols-3  gap-6 overflow-auto">
                    <div className='p-4 lg:w-full md:w-[25rem] sm:w-[18rem] rounded-lg border-[0.25px] border-[#000]' style={{ "boxShadow": "0px 2px 4px rgba(0, 0, 0, 0.25)" }}>
                        <img className='w-full' src={Aprt} alt="" />
                        <div className="px-4">
                            <p className='text-2xl font-semibold py-4'>2BHK Apartment for Sale</p>
                            <div className='flex justify-between flex-row pb-8'>
                                <div className='flex items-center'>
                                    <img className='w-5 h-5' src={LOcation} alt="" />
                                    <p className='text-[16px] font-normal ml-2'>Behala</p>
                                </div>
                                <div className='text-[16px] font-normal'>
                                    ₹15,000
                                </div>
                            </div>
                            <div className="flex flex-col gap-2">
                                <button className='bg-[#7F56D9] py-2 rounded-md text-white text-xl' style={{ "boxShadow": "0px 2px 4px #000" }}> Contact Now </button>
                                <button className='border-[1px] border-[] py-2 rounded-md text-xl' style={{ "boxShadow": "rgb(171 164 164) 0px 2px 4px" }}> Learn More </button>
                            </div>
                        </div>
                    </div>
                    <div className='p-4 lg:w-full md:w-[25rem] sm:w-[18rem] bg-[#4B2FB7] rounded-lg border-[0.25px] border-[#000]' style={{ "boxShadow": "0px 2px 4px rgba(0, 0, 0, 0.25)" }}>
                        <img className='w-full' src={Aprt} alt="" />
                        <div className="px-4">
                            <p className='text-2xl font-semibold py-4 text-white'>2BHK Apartment for Sale</p>
                            <div className='flex justify-between flex-row pb-8'>
                                <div className='flex items-center'>
                                    <img className='w-5 h-5 text-white' src={Location1} alt="" />
                                    <p className='text-[16px] font-normal ml-2 text-white'>Behala</p>
                                </div>
                                <div className='text-[16px] font-normal text-white'>
                                    ₹15,000
                                </div>
                            </div>
                            <div className="flex flex-col gap-2">
                                <button className='bg-[#7F56D9] py-2 rounded-md text-white text-xl' style={{ "boxShadow": "0px 2px 4px #000" }}> Contact Now </button>
                                <button className='border-[1px] bg-white border-[] py-2 rounded-md text-xl' style={{ "boxShadow": "rgb(0,0,0,0.45) 0px 2px 4px" }}> Learn More </button>
                            </div>
                        </div>
                    </div>
                    <div className='p-4 lg:w-full md:w-[25rem] sm:w-[18rem] bg-[#9277FB] rounded-lg border-[0.25px] border-[#000]' style={{ "boxShadow": "0px 2px 4px rgba(0, 0, 0, 0.25)" }}>
                        <img className='w-full' src={Aprt} alt="" />
                        <div className="px-4">
                            <p className='text-2xl font-semibold py-4 text-white'>2BHK Apartment for Sale</p>
                            <div className='flex justify-between flex-row pb-8'>
                                <div className='flex items-center'>
                                    <img className='w-5 h-5 text-white' src={Location1} alt="" />
                                    <p className='text-[16px] font-normal ml-2 text-white'>Behala</p>
                                </div>
                                <div className='text-[16px] font-normal text-white'>
                                    ₹15,000
                                </div>
                            </div>
                            <div className="flex flex-col gap-2">
                                <button className='bg-[#7F56D9] py-2 rounded-md text-white text-xl' style={{ "boxShadow": "0px 2px 4px #000" }}> Contact Now </button>
                                <button className='border-[1px] bg-white border-[] py-2 rounded-md text-xl' style={{ "boxShadow": "0px 2px 4px #000" }}> Learn More </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex py-8 w-full justify-center">
                    <ul className='flex justify-center gap-2'>
                        <li className='bg-[#341F87] w-2 h-2 rounded-full cursor-pointer'></li>
                        <li className='bg-[#341F87] w-2 h-2 rounded-full cursor-pointer'></li>
                        <li className='bg-[#341F87] w-2 h-2 rounded-full cursor-pointer'></li>
                    </ul>
                </div>
            </section>
        </>
    );
}

export default SimilarCard;
