import React from 'react';

const ImageCard = (props) => {
    return (
        <div className='shadow-lg'>
            <img className='rounded-[13px] w-full' src={props.image} alt="Home" style={{"boxShadow": "0px 3px 7px #4e4d4d"}} />
        </div>
    );
}
export default ImageCard;
