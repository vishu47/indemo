import React from 'react';
import ImageCard from './imageCard';
import Home2 from '../assets/img/home2.png'
import Home from '../assets/img/home.png'
import Whatsapp from '../assets/img/what.svg'

const Main = () => {
    return (
        <>
            <section className=' lg:py-8 md:py-6 sm:py-4'>
                <button className='bg-[#7F56D9] rounded-lg text-white md:text-3xl sm:text-xl px-6 py-2 shadow-lg' >For Rent</button>
                <p className='md:text-4xl sm:text-2xl py-4 font-semibold'>2BHK Apartment for Sale in Newtown, Kolkata, West Bengal</p>
                <div className="flex md:flex-row sm:flex-col gap-4 py-2">
                    <div className="md:w-1/2 sm:w-full">
                        <ImageCard image={Home} />
                    </div>
                    <div className="md:w-1/2 sm:w-full grid grid-flow-row grid-cols-2 gap-4">
                        <ImageCard image={Home2} />
                        <ImageCard image={Home2} />
                        <ImageCard image={Home2} />
                        <ImageCard image={Home2} />
                    </div>
                </div>
                <div className="">
                    <ul className='w-auto flex flex-row justify-end'>
                        <li className='border-2 border-[#7f56d9] rounded-lg w-auto py-1 px-6 my-4 mx-2'>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-7 h-7 text-std">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
                            </svg>

                        </li>
                        <li className='border-2 border-[#7f56d9] rounded-lg w-auto py-1 px-6 my-4 mx-2'>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-7 h-7 text-std">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
                            </svg>

                        </li>
                        <li className='border-2 border-[#7f56d9] rounded-lg w-auto py-1 px-6 my-4 mx-2'>
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-7 h-7 text-std">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 21L3 16.5m0 0L7.5 12M3 16.5h13.5m0-13.5L21 7.5m0 0L16.5 12M21 7.5H7.5" />
                            </svg>
                        </li>
                    </ul>
                </div>
                <p className='text-std md:text-4xl sm:text-3xl' style={{ "fontWeight": "600" }}>₹25,000</p>
                <div className='flex justify-between lg:flex-row md:flex-col sm:flex-col'>
                    <div className="flex flex-col">
                        <p className='text-[22px] py-2'>SP Sukhobrishti Ln, Action Area III, Newtown, Kolkata, West Bengal 700135, India</p>
                    </div>
                    <div className="flex sm:flex-row xs:flex-col" >
                        <ul className='flex justify-end gap-4 items-center'>
                            <li className='bg-[#1FC87F] py-3 px-4 rounded-[13px]' style={{"boxShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)"}}>
                                <img className='lg:w-[35px] lg:h-[35px] md:w-[30px] md:h-[30px] sm:w-[25px] sm:h-[25px]' src={Whatsapp} alt="" />
                            </li>
                            <li className='bg-[#7F56D9] h-full px-12 rounded-[13px]' style={{"boxShadow": "0px 4px 4px rgba(0, 0, 0, 0.25)"}}>
                                <p className='lg:text-3xl md:text-2xl sm:text-xl text-white flex items-center h-full' >Contact Owner</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </section>
        </>
    );
}

export default Main;
