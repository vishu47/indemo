import DetailCard from './component/detailCard';
import Header from './component/header';
import Main from './component/main';
import SimilarCard from './component/similarCard';
import SubHeader from './component/subHeader';

function App() {
  return (
    <>
      <section className='pb-8'>
        <Header />
        <section className='lg:px-16 md:px-8 sm:px-4'>
          <Main />
          <SubHeader />
          <DetailCard />
          <SimilarCard />
        </section>
      </section>
    </>
  );
}

export default App;
